package com.udacity.sandwichclub.utils;

import android.widget.LinearLayout;

import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {

    public static Sandwich parseSandwichJson(String json) {
        try {
            JSONObject root = new JSONObject(json);
            JSONObject name = root.getJSONObject("name");
            String mainName=name.getString("mainName");
            List<String> alsoKnownList=new ArrayList<>();
            JSONArray alsoKnownAs = name.getJSONArray("alsoKnownAs");
            for (int i = 0; i < alsoKnownAs.length(); i++) {
                String alsoKnownAsName=alsoKnownAs.getString(i);
                alsoKnownList.add(alsoKnownAsName);
            }

            String placeOfOrigin = root.getString("placeOfOrigin");
            String description = root.getString("description");
            List<String> ingredientsList=new ArrayList<>();
            JSONArray ingredients = root.getJSONArray("ingredients");
            for (int i = 0; i < ingredients.length(); i++) {
               String ingredientString=ingredients.getString(i);
               ingredientsList.add(ingredientString);
            }
            String image = root.getString("image");
    Sandwich sandwich=new Sandwich(mainName,alsoKnownList,placeOfOrigin,description,image,ingredientsList);
return sandwich;
        } catch (JSONException e) {
            e.printStackTrace();

        }
        return null;
    }
}
